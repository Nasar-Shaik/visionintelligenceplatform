# AI runtime benchmark — measured 2026-08-05

> Generated from a live run by `scripts/nightly/report.mjs`.
>
> ⚠️ **This is a run record, not the platform's reference page.** The committed reference lives at
> [`docs/project/AI_RUNTIME_BENCHMARK.md`](../../../docs/project/AI_RUNTIME_BENCHMARK.md) and is
> updated only by a person: `scripts/benchmark.sh --promote 2026-08-05`. A permanent
> reference a machine can rewrite at 03:00 is not a reference.

**Commit** `13f9876` · **execution provider** CPUExecutionProvider

## Capacity ladder

| Cameras | Offered fps | Analysed fps | Detections/s | Avg | p95 | Dropped | Drop % | Queue peak | Runtime CPU / RAM |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :-: | ---: |
| **1** | 2.3 | **2.3** | 4.6 | 69.9 ms | 119.3 ms | 0 | 0.0 % | 0/0 | 76 % / 101 MB |
| **2** | 4.5 | **4.5** | 9.0 | 54.4 ms | 108.1 ms | 0 | 0.0 % | 0/0 | 151 % / 102 MB |
| **4** | 9.3 | **8.7** | 17.4 | 60.8 ms | 121.4 ms | 11 | 4.7 % | 2/0 | 282 % / 110 MB |
| **8** | 18.1 | **15.6** | 31.1 | 69.9 ms | 129.8 ms | 64 | 14.2 % | 0/0 | 661 % / 111 MB |
| **12** | 28.4 | **22.9** | 45.8 | 77.9 ms | 156.2 ms | 122 | 17.2 % | 5/0 | 610 % / 114 MB |
| **16** | 39.1 | **29.5** | 59.0 | 87.5 ms | 164.1 ms | 238 | 24.4 % | 10/0 | 683 % / 116 MB |

**Sustainable: 2 camera(s)** — the largest rung inside a 2 % frame-loss budget with
no earlier rung breaching it.

## Warm-up

| | Unwarmed | Warmed |
| --- | --- | --- |
| First inference | 41.2 ms | 38.8 ms |
| Steady state | 35.2 ms | 36.4 ms |
| Warm-up itself | — | 39 ms |

## Reproducibility

20 runs of one frame · confidence variance 4.930380657631324e-32 · distinct values per detection: 1, 1
