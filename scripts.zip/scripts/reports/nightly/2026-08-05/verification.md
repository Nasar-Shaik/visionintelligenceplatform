# Verification detail — 2026-08-05

What each stage asserted, and what it reported. The summary is the verdict; this is the evidence.

## ✅ preflight — passed

**stack up, runtime healthy, 319GB free**

```
  ✓ the docker daemon is answering
  ✓ vip-prod-gateway-1 — running/healthy
  ✓ vip-prod-media-1 — running/healthy
  ✓ vip-prod-inference-1 — running/healthy
  ✓ vip-prod-console-1 — running/healthy
  ✓ enough disk for image rebuilds
  · docker build cache reclaimable: 21GB (scripts/cleanup.sh)
  ✓ the runtime reports health ok
  ✓ the tree is clean — a mutation restore can only put back what it took
```

## ✅ gate — passed

**all gates green · python 934**

```
  ✓ format
  ✓ typecheck
  ✓ lint
  ✓ unit tests
  ✓ build
  ✓ python suite
```

## ✅ deployment — passed

**deployment matches 13f9876**

```
  ✓ 0a · ⚠️ the working tree is clean — what is deployed can be named by a commit hash — 13f9876a
  ✓ 1·identity — every byte that executes is the byte that was built — 24 runtime files identical
  ✓ 1·tenant — every byte that executes is the byte that was built — 21 runtime files identical
  ✓ 1·camera — every byte that executes is the byte that was built — 36 runtime files identical (1 .d.ts differ in union order — they do not execute)
  ✓ 1·media — every byte that executes is the byte that was built — 34 runtime files identical
  ✓ 1·events — every byte that executes is the byte that was built — 25 runtime files identical
  ✓ 1·rules — every byte that executes is the byte that was built — 41 runtime files identical
  ✓ 1·workflow — every byte that executes is the byte that was built — 36 runtime files identical
  ✓ 1·notify — every byte that executes is the byte that was built — 32 runtime files identical
  ✓ 1·evidence — every byte that executes is the byte that was built — 33 runtime files identical
  ✓ 1·gateway — every byte that executes is the byte that was built — 23 runtime files identical
  ✓ 2·auth — every byte that executes is the byte that was built (in identity) — 6 runtime files identical
  ✓ 2·config — every byte that executes is the byte that was built (in identity) — 12 runtime files identical
  ✓ 2·contracts — every byte that executes is the byte that was built (in identity) — 54 runtime files identical
  ✓ 2·crypto — every byte that executes is the byte that was built (in camera) — 3 runtime files identical
  ✓ 2·messaging — every byte that executes is the byte that was built (in events) — 6 runtime files identical
  ✓ 2·permissions — every byte that executes is the byte that was built (in identity) — 3 runtime files identical
  ✓ 2·storage — every byte that executes is the byte that was built (in media) — 6 runtime files identical
  ✓ 2·tenancy — every byte that executes is the byte that was built (in identity) — 5 runtime files identical
  ✓ 3a·console — every byte that executes is the byte that was built — 47 runtime files identical
  · the edge serves: index-BE_zMb_B.js, vendor-react-eJZt6GTu.js, vendor-C0ImqHz6.js, vendor-state-D0WvlJOS.js, vendor-radix-CwIdpD7u.js
  ✓ 3b · ⚠️ the bundle the browser is handed is the one this tree builds — 5 content-hashed chunks match
  ✓ 4·identity — the container runs the current image, not one it was started with — b15dc153795e
  ✓ 4·tenant — the container runs the current image, not one it was started with — 1885a0ff6a46
  ✓ 4·camera — the container runs the current image, not one it was started with — ded4016b0404
  ✓ 4·media — the container runs the current image, not one it was started with — 1df9203ab622
  ✓ 4·events — the container runs the current image, not one it was started with — f9bb1bdfdbb8
  ✓ 4·rules — the container runs the current image, not one it was started with — 5051551d1bb6
  ✓ 4·workflow — the container runs the current image, not one it was started with — 4239a31da039
  ✓ 4·notify — the container runs the current image, not one it was started with — 642f824ecad9
  ✓ 4·evidence — the container runs the current image, not one it was started with — 6e21cfc95735
  ✓ 4·gateway — the container runs the current image, not one it was started with — e2b6634b35ba
  ✓ 4·console — the container runs the current image, not one it was started with — 526d65dcd2f4
  ✓ 4·inference — the container runs the current image, not one it was started with — a82cb1bc9b3f
  ✓ 5a · ⚠️ the image that reseeds a demonstration carries the committed seed — 80752db37149
  ✓ 6a·inference — every byte that executes is the byte that was built — 160 runtime files identical
  ✓ every running byte matches the commit
```

## ✅ boundary — passed

**boundary and import graph clean**

```
  ✓ §A the runtime is called from exactly one place — services/media/src/adapters/http-frame-sink.ts
  ✓ §B only media knows where the runtime lives — services/media/src/config/env.ts
  ✓ §C no service, app or package names a model implementation concept in code — clean
  ✓ §D the detection-result parse was found and has fields — 5 field(s)
  ✓ §D every field read off a detection result exists in the frozen contract — detections, inferenceMs, frameLatencyMs, executionProvider, model
  ✓ contracts and the perception boundary hold
  · @vip/auth [shared] packages/auth
  · @vip/config [shared] packages/config
  · @vip/contracts [shared] packages/contracts
  · @vip/crypto [shared] packages/crypto
  · @vip/messaging [shared] packages/messaging
  · @vip/permissions [shared] packages/permissions
  · @vip/storage [shared] packages/storage
  · @vip/tenancy [shared] packages/tenancy
  · @vip/service-camera [service] services/camera
  · @vip/service-events [service] services/events
  · @vip/service-evidence [service] services/evidence
  · @vip/service-gateway [service] services/gateway
  · @vip/service-identity [service] services/identity
  · @vip/service-media [service] services/media
  · @vip/service-notify [service] services/notify
  · @vip/service-rules [service] services/rules
  · @vip/service-tenant [service] services/tenant
  · @vip/service-workflow [service] services/workflow
  · @vip/console [app] apps/console
  ✓ the import graph has no violations
```

## ✅ runtime — passed

**inference verified end to end**

```
  ✓ the deployed image is built for the real backend — label=onnx
  ✓ the running container is configured for the real backend — onnx
  ✓ ⚠️ models resolve from the image, not from a tracking server it must reach at boot — local
  ✓ every registered artifact matches its recorded sha256 —   ✓ yolox-nano: verified
  ✓ onnxruntime is installed in the image — v1.19.2
  ✓ ⚠️ the serving image does not carry the authoring dependencies — mlflow absent
  ✓ health is derived from the capabilities, and every one is READY — ok
  ✓ the execution provider is what the session reported, not what was requested — CPUExecutionProvider
  ✓ the perception capability is loaded — perception.person-detection=READY
  ✓ the model bound is the catalogue default — yolox-nano
  ✓ the session was warmed up during load, not on the first frame — 89.82ms
  ✓ the pixel path is recorded as a reproducible fingerprint — 1.0/letterbox-416x416-NCHW-float32-BGR-pad114
  ✓ every registered model has its artifact on disk — 1 registered
  ✓ capacity reads the cgroup quota, not the host core count — 10 cores
  ✓ ⚠️ GPU reports absent rather than 0% — there is none in this deployment — null
  ✓ the runtime answered
  ✓ exactly 2 detections, matching the scene — got 2
  ✓ every detection is a person — person, person
  ✓ both are confident, not marginal — 0.925, 0.873
  ✓ boxes are inside the frame and have area — [0.27,0.22,0.21,0.77] [0.49,0.26,0.22,0.72]
  ✓ each detection carries its own identity — det_392256fcd5ed33f05468 det_337ac3aa271a89aacb2b
  ✓ the document says how to read it — 1.1
  ✓ model id + version travel with the result — yolox-nano v1.0.0
  ✓ the execution provider travels with the result — CPUExecutionProvider
  ✓ the pixel path travels with the result — 1.0/letterbox-416x416-NCHW-float32-BGR-pad114
  ✓ the confidence floor travels with the result — 0.5
  ✓ inference latency is measured — 48.859ms
  ✓ capture → detection is measured — 393ms
  ✓ the runtime version travels with the result — 0.1.0
  ✓ ⚠️ reprocessing the same frame yields the same detection ids — det_392256fcd5ed33f05468 det_337ac3aa271a89aacb2b
  ✓ the runtime answered
  ✓ ⚠️ a colour-bar test pattern produces ZERO detections — got 0
  ✓ and the model still ran — an empty answer is work, not a skip — 31.143ms
  ✓ the model-format suite passes in the image — 20 tests
  ✓ ⚠️ and it was NOT skipped here — OK
  ✓ a fixture camera exists
  ✓ frames from a real RTSP source reached the runtime — 35 frames
  ✓ ⚠️ and produced detections — the whole path, end to end — 70 detections
  ✓ labelled `person`, from a photograph of people — 70 person detections
  ✓ nearly every frame of a scene containing people detects people — 100%
  ✓ media records the inference time the runtime reported — 75.7ms
  ✓ the blank camera also delivers frames — 28 frames
  ✓ ⚠️ and a test-pattern camera detects nobody — not one person across the window — 0 people across 28 analysed frames
  ✓ an administrator can read the runtime view — 200
  ✓ the deployment reports perception as configured
  ✓ and the runtime answered through media — 3ms
  ✓ the page would show real detections — 93885
  ✓ ⚠️ a viewer is refused — `system:inspect`, not `*:read` — 403
  ✓ an unauthenticated caller is refused — 401
  ✓ ⚠️ the runtime is still not routed through the gateway — 404
  ✓ and still publishes no port to the host — none
  ✓ every rung analysed frames and produced detections
  ✓ ⚠️ frame accounting closes at every rung — nothing is lost silently — 1:40=41+0+0 2:82=81+0+0 4:160=158+2+0 8:319=284+35+0 16:657=518+132+0
  ✓ no frame was refused or unreachable at any rung — 1:0 2:0 4:0 8:0 16:0
  ✓ the runtime’s memory stays bounded under load — 128MB at 16 cameras
  ⚠️ CPU inference saturates within the ladder — frames first dropped at 4 cameras — the queue is doing its job, and this is the number that sizes a deployment
  ⚠️ inference latency at full load — 104ms per frame at 16 cameras on CPU
  ✓ real inference verified against the deployment
```

## ❌ dashboard — failed

**dashboard verification RED**

```
  ✓ the page is titled for what it reports
  ✓ the execution provider is the measured one — CPUExecutionProvider
  ✓ the loaded model is named
  ✓ the capability state is shown
  ✓ health is derived, not asserted
  ✓ ⚠️ and it shows what was actually SEEN — `person`, from a real photograph
  ✓ the registered model’s licence is visible to whoever operates it
  ✓ the preprocessing fingerprint is rendered, so a result can be reproduced
  ✓ ⚠️ GPU says “none in this deployment”, not “0%”
  ✓ nothing rendered as NaN, undefined or [object Object]
  ✓ the browser logged no errors
  ✓ the page fetched the runtime view and this run captured it
  ✓ the page renders labelled value cells to check — 28 cell(s)
  ✗ ⚠️ every number rendered traces to a value the deployment reported — unexplained: Mean confidence="0.889"
  ✓ no "0 %" stands in for a thing that does not exist — GPU = "none in this deployment"
  ✓ the page has a vocabulary for "nothing produced this"
  ✓ the page polls at the interval it claims — 12 requests/min
  ✓ ⚠️ and stops when the operator navigates away — 0 requests
  ✓ ⚠️ the page says so without being refreshed
  ✓ ⚠️ and says the thing an operator actually needs — perception failing is not recording failing
  ✓ it does not still claim health
  ✓ and recovers on its own when the runtime returns
  ✓ the page refuses a viewer
  ✓ ⚠️ and does not let the refusal read as an all-clear
  ✓ and leaks no runtime detail to them
  ✓ the sidebar does not advertise a page they cannot open
  ✗ dashboard verification failed (exit 1)
```

## ✅ integration — passed

**integration green**

```
  ✓ integration tests passed
```

## ✅ stability — passed

**35 min · 8755 frames · 2.00–2.00/frame · mem 108–119MB · p95 62–120ms · 137 dropped**

```
  · running 35 minutes across 2 cameras
  ✓ runtime memory is flat across the run — 108MB → 112MB (+3.0%)
  ✓ and the process agrees with the container about it — RSS 133MB → 134MB
  ✓ p95 inference latency does not drift — 93ms → 95ms (+1.9%)
  ✓ CPU is stable, not climbing — 127% → 142%
  ✓ ⚠️ detection consistency: exactly two people, every minute, for the whole run — 2.00–2.00 detections per frame
  ✓ no frame was refused or unreachable in the whole run — 0 failures
  ✓ the queue never built up without draining — peak depth 0
  ✓ 2 cameras is inside capacity — 137 dropped of 8892 offered (1.54%)
  ✓ no minute passed with nothing analysed — 0 silent minute(s)
  ✓ per-minute samples captured
  ✓ stability checks passed over 35 minutes
```

## ✅ benchmark — passed

**sizing 2 cameras (p95 108ms, 151% CPU) · top rung 16 cams 24.4% dropped**

```
  · capacity ladder, warm-up and reproducibility
  ✓ the runtime warms the session during load — 39ms
  ⚠️ warm-up buys less than 10% — unwarmed 41.2ms vs warmed 38.8ms — it moves cost to load rather than removing it
  ✓ a warmed runtime has no first-frame outlier — first 38.8ms vs steady 36.4ms
  ✓ the container reaches READY quickly either way — 1.5s
  ✓ every run answered — 20/20
  ✓ the detection count never varies — counts: 2
  ✓ ⚠️ every field except the clock is byte-identical across all runs — 1 distinct result(s)
  ✓ ⚠️ every confidence is the identical double across all runs — not "close", identical — d0: 0.924996 × 20 runs, 1 distinct · d1: 0.872955 × 20 runs, 1 distinct
  ✓   schemaVersion is present and reproducible — "1.1"
  ✓   model.id is present and reproducible — "yolox-nano"
  ✓   model.version is present and reproducible — "1.0.0"
  ✓   executionProvider is present and reproducible — "CPUExecutionProvider"
  ✓   preprocessingVersion is present and reproducible — "1.0/letterbox-416x416-NCHW-float32-BGR-pad114"
  ✓   confidenceThreshold is present and reproducible — 0.5
  ✓   inferenceMs is present and reproducible — 34.516
  ✓   frameLatencyMs is present and reproducible — 120
  ✓ there is a sustainable camera count — 2 cameras
  ✓ no frame was refused or unreachable at any rung
  ✓ ⚠️ detection consistency holds at every rung — two people, every frame, to saturation — 1:2.00 2:2.00 4:2.00 8:2.00 12:2.00 16:2.00
  ✓ runtime memory is flat across the whole ladder — 101–116MB
  ⚠️ SIZING: 2 camera(s) per host at 2 fps on CPU — p95 108ms, 151% CPU, 102MB
  ⚠️ capacity is CPU-bound and well below the frame path — the transport carried 16 cameras with zero loss in Phase 2; inference sustains 2
  ✓ the operator route answers
  ✓   health is the runtime's own number — page ok · runtime ok
  ✓   executionProvider is the runtime's own number — page CPUExecutionProvider · runtime CPUExecutionProvider
  ✓   runtimeVersion is the runtime's own number — page 0.1.0 · runtime 0.1.0
  ✓   framesProcessed is the runtime's own number — page 3201 · runtime 3201
  ✓   detectionsTotal is the runtime's own number — page 6402 · runtime 6402
  ✓   latencyP95Ms is the runtime's own number — page 167.749 · runtime 167.749
  ✓   GPU is absent rather than 0% — null
  ✓   CPU cores come from the cgroup quota — 10
  ✓   the pipeline counters are internally consistent — 66331 offered ≥ 61245 delivered
  ✓   the page states when it was observed, and it is now
  ✓ capacity samples captured
  ✓ benchmark checks passed
```

## ❌ mutation — failed

**6 mutation(s) red-then-green · with failures**

```
  · running the full suite
  ✗ the mutation suite reported failures (exit 1)
  ✓ the working tree is exactly as this stage found it
```

## ✅ report — passed

**scripts/reports/nightly/2026-08-05/summary.md**

```
  ✓ summary.md, verification.md and benchmark.md written
```

