# Nightly verification — every run

**Latest:** [`latest/summary.md`](latest/summary.md) — a stable path that always points at the
newest run, so it never needs a date.

| Run | Verdict | Profile | Commit | Duration | What it says |
| --- | --- | --- | --- | ---: | --- |
| [`2026-08-05`](2026-08-05/summary.md) | ❌ RED | `nightly` | `13f9876` | 1h 2m | 2 stage(s) failed |

---

_Rebuilt by `scripts/nightly/report.mjs` on every run. Old runs are pruned by
`scripts/cleanup.sh --prune` (KEEP_RUNS days), and this table is regenerated from what survives._
